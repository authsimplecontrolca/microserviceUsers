export const activeModels = {
  User: 'on',
  Role: 'on',
  TypeDocument: 'on',
  // agrega más modelos aquí
};
